Robótica 2020-2021
Práctica 3
Grupo 011


Ejecución del script
====================

# Ejecutar el tracker volcando el log en el fichero logs/p3.csv
python p3_base.py -f p3.csv

# Mostrar gráfica con el recorrido del log guardado
python read_log.py -f p3.csv

