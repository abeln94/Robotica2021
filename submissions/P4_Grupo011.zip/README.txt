Robótica 2020-2021
Práctica 4
Grupo 011


Ejecución del script
====================

# Ejecutar con mapa 0 empezando en la casilla [0,0] con meta en la [2,0], volcando el log en el fichero logs/p4.csv
python p4.py -start 0 0 -end 2 0 -m mapa0.txt -f p4.csv

# Mostrar gráfica con el recorrido del log guardado
python read_log.py -f p4.csv

